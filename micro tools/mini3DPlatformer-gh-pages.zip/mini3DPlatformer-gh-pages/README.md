Mini 3D Platformer bootstrap/demo
===

CSS3D:

Demo 1: https://xem.github.io/mini3DPlatformer/css3d/1 (hero moves north / east / south / west only)

Demo 2: https://xem.github.io/mini3DPlatformer/css3d/2 (hero rotates on itself and moves forward and backwards)

Demo 3: https://xem.github.io/mini3DPlatformer/css3d/3 (3rd person camera)


WEBGL:

Demo:  https://xem.github.io/mini3DPlatformer/webgl (3rd person camera)